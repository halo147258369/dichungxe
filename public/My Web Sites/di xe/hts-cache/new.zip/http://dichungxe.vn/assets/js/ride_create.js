function prepareListItem()
{
	$('.list_item').hover(function(){
		$('.list_item').removeClass('selected');
		$(this).addClass('selected');
	});
}
$(document).ready(function(){
	 $('#selectPriceType').change(function(){
	    var vehicle = $('#vehicle').val();
        var selectPriceType = $('#selectPriceType').val(); 
	   	var path = '#vehicle input:checked';
    	var id = $(path).val();
    	var selectPrice = parseInt($('#vehicle_price_'+id).val());
        var vehicle_price_service = parseInt($('#vehicle_price_service_'+id).val());
    	var totalLength = parseFloat($('#total_length').val());
    	var isService = parseInt($('#is_service_'+id).val())==1?true:false; //xe dvu
    	var isBoss = $('#who #who_1:checked').size()>0?true:false; //chu xe
    	var otherCost = parseInt($('#cost_other').val());
    	var totalSeat = parseInt($('#total_seats').val());
    	var seatLeft = parseInt($('#seats').val());

        if(selectPriceType == '1')
        {
            var cost = parseInt(totalLength*selectPrice/1000);
        }
        if(selectPriceType == '2')
        {
          if(id == '1')
           {
               
                if(totalLength >= '25000')
                {
                     var cost = parseInt(((25000*vehicle_price_service) + ((totalLength - 25000)*10500))*75/100/1000 );
                }
                else
                {
                    var  cost = parseInt(totalLength*vehicle_price_service*75/100/1000);
                }
           }
          if(id == '2')
          {
    
                if(totalLength >= '5000')
                {
                     var cost = parseInt(((5000*vehicle_price_service) + ((totalLength - 5000)*4000))*75/100/1000);
                }
                else
                {
                    var  cost = parseInt(totalLength*vehicle_price_service*75/100/1000);
                }
          }
        }
        if(selectPriceType == '3')
        {
           if(id == '1')
           {
                if(totalLength >= '25000')
                {
                     var cost = parseInt(((25000*vehicle_price_service) + ((totalLength - 25000)*10800))/1000);
                }
                else
                {
                     var  cost = parseInt(totalLength*vehicle_price_service/1000);
                }
           }
          if(id == '2')
          {
                if(totalLength >= '5000')
                {
                     var cost = parseInt(((5000*vehicle_price_service/1000) + ((totalLength - 5000)*4000/1000)));
                }
                else
                {
                    var  cost = parseInt(totalLength*vehicle_price_service/1000);
                }
          }
        }
        if(selectPriceType == '4')
        {
           var  cost = '0';
        }
	    if(selectPriceType == '5'){
        	var cost = '';
        }
    	//set total cost
    	$('#cost').val(cost);
    	var totalCost = cost+otherCost;
    	//set total cost
    	$('#cost_total').val(totalCost);
    	calcPriceRideCreate(selectPrice, totalLength, isService?1:0, isBoss?1:0, totalCost, totalSeat, seatLeft, isBike(), isBicycle(), isXeom());
        jQuery.ajax({
              type: "POST", 
              url: "/ride/priceType", 
              dataType:"json", 
              data:{"selectPriceType":selectPriceType}, 
              success:function(response){
                  var code = response.code;
                  var msg = response.msg;
                  $('#contentPriceSelect').html(msg);
                    $('#intend_km').html(parseInt($('#total_length').val())/1000);
                	var o = $('#vehicle').find('input:checked');
                	var val = o.val();
                    var selectPriceType = $('#selectPriceType').val(); 
                    if(val == '1')
                    {
                        $('#intend_vehicle').html('Xe taxi');
                        $('#price_discount_vehicle').html('<b>10500</b>');
                    } 
                    if(val == '2'  )
                    {
                        $('#intend_vehicle').html('Xe Ôm');
                        $('#price_discount_vehicle').html('<b>4000</b>');
                    } 
                    if(selectPriceType !== '1')
                    {
                         
                        $('#intend_cost').html($('#vehicle_price_service_'+val).val());
                    }
                    else{
                        if(val == '1')
                        {
                             $('#intend_vehicle').html('Xe Ô tô');
                        }
                        if(val == '2')
                        {
                             $('#intend_vehicle').html('Xe Máy');
                        }
                       
                         $('#intend_cost').html($('#vehicle_price_'+val).val());
                    }
                    
              },
              error:function (xhr, ajaxOptions, thrownError){
              }
          });
	 });
	 $('#step_2 .back, #step_3 .back, #step_4 .back, #step_5 .back').click(function() {
			id = $(this).attr('back-to');
			$('#step_1, #step_5, #step_4, #step_3, #step_2').addClass('hidden');
			$('#'+id).removeClass('hidden');
	 });
	 //step1
	 $('#step_1 .changestep #next_step1').click(function(){
		if(!($('#start_pos').val().length > 0 && $('#end_pos').val().length > 0)) {
			alert('Bạn vui lòng nhập đầy đủ điểm đi và đến');
			return false;
		} 
		$('#step_1').addClass('hidden');
		$('#step_2').removeClass('hidden');
	 });
	 //step2
	 $('#step_2 .changestep #next_step2').click(function(){
			if($('#who input:checked').size() == 0) {
				$('#who .bigradio').addClass('errored');
				alert('Bạn phải chọn là người lái xe hay hành khách');
				return false;
			}
			if($('#vehicle input:checked').size() == 0) {
				$('#vehicle .bigradio').addClass('errored');
				alert('Bạn hãy chọn phương tiện');
				return false;
			}
			$('#step_2').addClass('hidden');
			$('#step_3').removeClass('hidden');
		});
		$('#who input').change(function(){
			$('#who .bigradio').removeClass('errored'); 
		});
		$('#vehicle input').change(function(){
			$('#vehicle .bigradio').removeClass('errored');
			var sid = '#default_seat_left_'+$(this).val();
			var tsid = '#default_total_seat_'+$(this).val();
			var totalSeat = parseInt($(tsid).val());
			$('#total_seats').val(totalSeat);
			$('#seats').val($(sid).val());
			if(hanhkhachdixedichvu())
			{
				$('#seats').val(totalSeat-2);
			}
			$('.errormsg').html('');
		});
	//step 3
	$('#step_3 .back').click(function(){
		$('#step_2').removeClass('hidden');
		$('#step_3').addClass('hidden');
	});
	$('#tabs .tab').click(function(){
		$('#tabs .tab').removeClass('active');
		$(this).addClass('active');
		var index = $('#tabs .tab').index(this);
		$('.trip_frame').addClass('hidden');
		$('.trip_frame').eq(index).removeClass('hidden');
		$('#tab_clicked').val($(this).attr('id'));
	});
	//tab daily
	$('.pillbuttons div').click(function(){
		$('.pillbuttons div').removeClass('chosen');
		$(this).addClass('chosen');
		$('#delay_time').val($(this).attr('value'));
	}); 
	$('#step_3 #singletripwrapper #back').click(function(){
		if($('#step_3 #singletripwrapper #back:checked').size() >0 )
		{
			$('#return-date').removeAttr('disabled');
			$('#back_time').removeAttr('disabled');
		}
		else
		{
			$('#return-date').attr('disabled', 'disabled');
			$('#back_time').attr('disabled', 'disabled');
		}
	});
	//step 3
	$('#step_3 #singletripwrapper #return-date, #step_2 #singletripwrapper #depart-date, #three_time_0, #back_time_0').focus(function(){
		$('#step_3 .errored').removeClass('errored');
	});
	$('#commute-table .field1 .checkbox').click(function(){
		$('#step_3 .errored').removeClass('errored');
		var index = $('#commute-table .field1 .checkbox').index(this);
		var select = $('#commute-table .field2 select').eq(index);
		var select2 = $('#commute-table .field4 select').eq(index);
		if(this.checked)
		{
			select.removeClass('hidden');
			select2.removeClass('hidden');
		}
		else
		{
			select.addClass('hidden');
			select2.addClass('hidden');
		}
	});
	$('#commute-table .field3 .checkbox').click(function(){
		$('#step_3 .errormsg').html('');
		$('#step_3 .errored').removeClass('errored');
		var index = $('#commute-table .field3 .checkbox').index(this);
		var select = $('#commute-table .field4 select').eq(index);
		if(this.checked) {
			select.removeClass('hidden');
		}
		else {
			select.addClass('hidden'); 
		} 
	});
	$('.add_ride_weekly').click(function(){
		var dateDepart = $('#commute-table .field1 li').eq(1).html();
		var timeDepart = $('#commute-table .field2 li').eq(1).html();
		var dateReturn = $('#commute-table .field3 li').eq(1).html();
		var timeReturn = $('#commute-table .field4 li').eq(1).html();
		var s = $('#commute-table .field1 li').size();
		$('#commute-table .field1').append('<li class="li_'+s+'">'+dateDepart+'</li>').find('select').eq(s-1).attr('name', 'tab_weekly[depart_day]['+s+']');
		$('#commute-table .field2').append('<li class="li_'+s+'">'+timeDepart+'</li>').find('select').eq(s-1).attr('name', 'tab_weekly[depart_time]['+s+']');
		$('#commute-table .field3').append('<li class="li_'+s+'">'+dateReturn+'</li>').find('select').eq(s-1).attr('name', 'tab_weekly[back_day]['+s+']');
		$('#commute-table .field4').append('<li class="li_'+s+'">'+timeReturn+'</li>').find('select').eq(s-1).attr('name', 'tab_weekly[back_time]['+s+']');
		$('#commute-table .field5').append('<li class="li_'+s+'"><span class="remove_ride_weekly" onclick="prepareRemoveRideWeeklyButton('+s+')">Xoá</li></li>');
	});
	$('#next_step3').click(function(){
	   $('#selectPriceType').val(1);
       $('#contentPriceSelect').html('Chi phí này được tính bằng chi phí tiêu hao nhiên liệu trên đường  ( bằng quãng đường dự kiến <B><span id="intend_km"></span></b>(Km)  ( được tính tự động bởi Google Maps)  nhân với chi phí trung bình của <b><span id="intend_vehicle"></span></b> trên một đơn vị km là <b><span id="intend_cost"></span></b>VNĐ /km theo giá xăng hiện hành  Thực tế có thể khác. Bạn có thể tự điều chỉnh cho phù hợp.');
           
	   var isBoss = $('#who #who_1:checked').size()>0?true:false; 
       if(isBoss == false)
       {
         $('#textChange').html('đồng ý');
       }
       else{
         $('#textChange').html('muốn');
       }
		var tabClicked = $('#tab_clicked').val();
		if(tabClicked == 'tab_once')
		{
			var dDate = $('#step_2 #depart-date').val();
			var dTime = $('#step_2 #there_time').val();
			if(parseInt(dTime) < 10)
				dTime = "0"+dTime;
			if(dDate == '')
			{
				$('#step_2 #depart-date').addClass('errored');
				jAlert('Chọn ngày đi');
				return false;
			}
			var now = new Date();
			var cTime = now.format("yyyy-mm-dd hh:MM");
			if(dDate+' '+dTime < cTime)
			{
				$('#step_2').find('#depart-date, #depart-time').addClass('errored');
				jAlert('Thời gian đi phải lớn hơn thời gian hiện tại');
				return false;
			}
			var k = '#step_2 #singletripwrapper';
			var bDate = $(k+' #return-date').val();
			var bTime = $('#step_2 #back_time').val();
			if(parseInt(bTime) < 10)
				bTime = "0"+bTime;
			if($(k+' #back:checked').size() >0)
			{
				if(bDate == '')
				{
					$(k+' #return-date').addClass('errored');
					jAlert('Chọn ngày về');
					return false;
				}
				else if(bDate+' '+bTime <= dDate+' '+dTime)
				{
					$(k+' #return-date').addClass('errored');
					jAlert('Ngày về không hợp lệ');
					return false;
				}
			}
			$(k+' #return-date,#step_2 #depart-date').removeClass('errored');
			$('#step_2 .errormsg').html('');
		} 
		$('#step_3').addClass('hidden');
		$('#step_4').removeClass('hidden');
		preparePrice();
	});
	$('#step_3 .back').click(function(){
		$('#step_2').removeClass('hidden');
		$('#step_3').addClass('hidden');
	});
	//step 4
	// incre decre price
	$('.input-arrows .increment, .input-arrows .decrement').click(function(){
		var obj = $(this).parent().parent().find('input[type="text"]').eq(0);
		var val = obj.val();
		var id = obj.attr('id');
		if(isNaN(val))
		{
			val = 0;
		}
		else
		{
			val = parseInt(val);
		}
		var cls = $(this).attr('class');
		var totalSeat = $('#step_4 #total_seats').val();
		if(isNaN(totalSeat) )
		{
			totalSeat = 4;
		}
		else
		{
			totalSeat = parseInt(totalSeat);
		}
		if(cls == 'increment')
		{
			val++;
		}
		else
		{
			val--;
		}
		if(val < 0 )
		{
			val = 0;
		}
		var seatLeft = $('#step_4 #seats').val();
		if(isNaN(seatLeft) )
		{
			seatLeft = 1;
		}
		else
		{
			seatLeft = parseInt(seatLeft);
		}
		if(id == 'total_seats' && val < seatLeft+1)
		{
			val ++;
		}
		else if(id != 'total_seats' && val >= seatLeft-1)
		{
			if(val < 1 )
				val = 1;
			else if(val >= totalSeat)
				val = totalSeat -1;
		}
		if(hanhkhachdixedichvu())
		{
			if(id == 'total_seats' && val-2 < seatLeft)
			{
				val = seatLeft+2;
			}
			else if(id == 'seats' && val+2 > totalSeat)
			{
				val = totalSeat-2;
			}
		}
		$(this).parent().parent().find('input[type="text"]').val(val);		
		preparePrice();
	});
	$('#step_4 input[name="price_method"]').change(function(){
		var val = $(this).val();
		var cls = {1: {hide: 'price_select_2', show: 'price_select_1'},
								2: {hide: 'price_select_1', show: 'price_select_2'}};
		if(!isMoto())
		{
			$('#step_4 .'+cls[val].hide).addClass('hidden');
			$('#step_4 .'+cls[val].show).removeClass('hidden');
		}
	});
	$('#step_4 .back').click(function(){
		$('#step_3').removeClass('hidden');
		$('#step_4').addClass('hidden');
	});
	$('#cost_other, #cost').keyup(function(){
		changePrice();
	});
	$('#step_4 #next_step4').click(function(){
		$('#step_5').removeClass('hidden');
		$('#step_4').addClass('hidden');
	});
});
function changePrice()
{
	var cost = parseInt($('#cost').val());
	var ocost = parseInt($('#cost_other').val());
	var totalCost = cost+ocost;
	$('#cost_total').val(totalCost);
	var totalSeat = parseInt($('#total_seats').val());
	$('#suggest_price_input').val(parseInt(totalCost/totalSeat));
}
var addRide = 0;
function add_ride(obj)
{
	if(addRide != 0)
	{
		return false;
	}
	addRide = 1;
	var params = {};
	$('#add_ride input[type=radio]:checked, #add_ride input[type=text], #add_ride input[type=hidden], #add_ride input[type=checkbox]:checked, #add_ride select, #add_ride textarea').each(function(){
		params[$(this).attr('name')] = $(this).val();
	});
	$(obj).parent().find('.loading_img').show();
	$(obj).hide();
	$.ajax({
		url: $('#add_ride').attr('action'),
		type: 'post',
		data: params,
		dataType: 'json',
		success: function(data) {
			addRide = 0;
			$(self).find('.loading_img').hide();
			jAlert(data.msg, 'Thông báo', function (){
				if(data.link)
					location.href = data.link;
			}); 
			$(obj).parent().find('.loading_img').hide();
			$(obj).show();
		}
	});
	return false;
}
function prepareRemoveRideWeeklyButton(index){
		if(index > 1)
		{
			$('#commute-table .field1 .li_'+index).remove();
			$('#commute-table .field2 .li_'+index).remove();
			$('#commute-table .field3 .li_'+index).remove();
			$('#commute-table .field4 .li_'+index).remove();
			$('#commute-table .field5 .li_'+index).remove();
		}
	}
function preparePrice()
{
	calcPrice();
	addOptionsCampuchia();
	calcForCampuchia();
	$('#intend_km').html(parseInt($('#total_length').val())/1000);
	var o = $('#vehicle').find('input:checked');
	var val = o.val();
    
	//$('#intend_vehicle').html(o.parent().find('label').html());
    if(val == '1')
    {
        $('#intend_vehicle').html('Xe Ô tô');
    } 
     if(val == '2')
    {
        $('#intend_vehicle').html('Xe Máy');
    } 
	$('#intend_cost').html($('#vehicle_price_'+val).val());
}
function calcForCampuchia()
{
	var cost = parseInt($('#cost').val());
	var totalSeat = parseInt($('#total_seats').val());
	if(isTaxi())
	{
		totalSeat--;
	}
	var seats = parseInt($('#seats').val());//so ghe trong
	var selectSeat = parseInt($('#select_seat').val());
	var price = Math.round(cost/(totalSeat-seats+selectSeat));
	$('#payment_price').val(price);
	//$('#max_price').val(Math.round(cost/(totalSeat-seats+1)));
	//$('#min_price').val(Math.round(cost/totalSeat));
}
$('#select_seat').change(function(){
	calcForCampuchia();
});
function addOptionsCampuchia()
{
	var seat = $('#seats').val();
	if(seat >= 0)
	{
		var opts = new Array();
		for(var i = 0; i <= seat; i++)
		{
			opts[i] = '<option value="'+i+'">'+i+'</option>'
		}
		if(opts.length > 0 )
		{
			$('#select_seat').html(opts.join(''));
		}
	}
}
function calcPrice(costChange)
{
	var path = '#vehicle input:checked';
	var id = $(path).val();
	var selectPrice = parseInt($('#vehicle_price_'+id).val());
	var totalLength = parseFloat($('#total_length').val());
	var isService = parseInt($('#is_service_'+id).val())==1?true:false; //xe dvu
	var isBoss = $('#who #who_1:checked').size()>0?true:false; //chu xe
	var otherCost = parseInt($('#cost_other').val());
	var totalSeat = parseInt($('#total_seats').val());
	var seatLeft = parseInt($('#seats').val());
    var cost = parseInt(totalLength*selectPrice/1000);
	if(costChange)
    {
        cost = costChange;
    }
	
	//set total cost
	$('#cost').val(cost);
	var totalCost = cost+otherCost;
	//set total cost
	$('#cost_total').val(totalCost);
	calcPriceRideCreate(selectPrice, totalLength, isService?1:0, isBoss?1:0, totalCost, totalSeat, seatLeft, isBike(), isBicycle(), isXeom());
}
function isTaxi()
{
	if($('#vehicle input[name="vehicle"]:checked').val() == 3)
	{
		return true;
	}
	return false;
}
function isMoto()
{
	var check = isBike() || isXeom() || isBicycle();
	if(check)
		$('.input-arrows').hide();
	else
		$('.input-arrows').show();
	return check;
}
function isBike()
{
	var path = '#vehicle input:checked';
	var id = $(path).val();
	return parseInt($('#is_bike_'+id).val())==1?true:false;
}
function isXeom()
{
	var path = '#vehicle input:checked';
	var id = $(path).val();
	return parseInt($('#is_xeom_'+id).val())==1?true:false;
}
function isBicycle()
{
	var path = '#vehicle input:checked';
	var id = $(path).val();
	return parseInt($('#is_bicycle_'+id).val())==1?true:false;
}
function hanhkhachdixedichvu(){
	if(isMoto())
	{
		return false;
	}
	var isBoss = $('#who #who_1:checked').size()>0?true:false; //chu xe
	if(!isBoss)
	{
		return true;
	}
	return false;
}
$('#step_3 #cost, #step_3 #cost_other, #step_3 #cost_total').keyup(function(){
	var c = parseInt($(this).val());
	if(!isNaN(c))
	{
		if($(this).attr('id') == 'cost')
			calcPrice(c);
		else
			calcPrice();
		addOptionsCampuchia();
		calcForCampuchia();
	}
})